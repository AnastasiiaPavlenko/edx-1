	var page = {
					langs : {
				 "form__label_name" : {
				 "ru" : "Имя"
				 ,"ua" : "Ім'я"
				 }
				 ,"form__label_surname" : {
				 "ru" : "Фамилия"
				 ,"ua" : "Прізвище"
				 }
				 ,"form__label_email" : {
				 "ru" : "Ваша электронная почта"
				 ,"ua" : "Ваша електрона пошта"
				 }
				 ,"form__label_number" : {
				 "ru" : "Ваш номер телефона"
				 ,"ua" : "Ваш номер телефона"
				 }
				 ,"form__label_address" : {
				 "ru" : "Ваш домашний адрес"
				 ,"ua" : "Ваша домашня адреса"
				 }
				 ,"form__label_question" : {
				 "ru" : "Как Вы о нас узнали?"
				 ,"ua" : "Як Ви про нас дізналися?"
				 }
				 ,"form__submit-button" : {
				 "ru" : "Отправить"
				 ,"ua" : "Надiслати"
				 }
				 ,"form__label_question-friends" : {
				 "ru" : "От друзей"
				 ,"ua" : "Від друзів"
				 }
				 ,"form__label_question-advert" : {
				 "ru" : "Из рекламы"
				 ,"ua" : "Із реклами"
				}
				,"form__label_question-internet" : {
				 "ru" : "Нашел в интернете"
				 ,"ua" : "Знайшов в інтернеті"
				}
	}
};

		  
Settings.init(page);
		  
